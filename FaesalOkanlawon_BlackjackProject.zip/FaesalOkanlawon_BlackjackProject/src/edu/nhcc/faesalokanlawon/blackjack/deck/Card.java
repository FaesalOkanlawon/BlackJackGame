package edu.nhcc.faesalokanlawon.blackjack.deck;

public class Card {
    private Suit suit;
    private Rank rank;
    public Card(Suit s, Rank r){
        suit = s;
        rank = r;
    }
    public int getRankValue(){
        return rank.getValue();
    }
    public String getRankName(){
        return rank.getName();
    }
    public String getSuitName(){
        return suit.getName();
    }

    public String toString(){
        return getRankName() + "of" + getSuitName();
    }

    public String getImagePath(){
        return "./cards/" + toString() + ".png";
    }
}
