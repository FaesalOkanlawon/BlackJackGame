package edu.nhcc.faesalokanlawon.blackjack.deck;

public enum Suit {
    HEARTS("hearts"), DIAMONDS("diamonds"),
    CLUBS("clubs"), SPADES("spades");
    Suit(String n){
        name = n;
    }
    private final String name;
    public String getName(){
        return name;
    }
}