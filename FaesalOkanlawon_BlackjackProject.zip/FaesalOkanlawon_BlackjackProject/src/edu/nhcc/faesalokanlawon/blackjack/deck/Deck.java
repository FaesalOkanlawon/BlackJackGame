package edu.nhcc.faesalokanlawon.blackjack.deck;

import java.util.ArrayList;

public class Deck {
    private ArrayList<Card> deck;

    public Deck(){
        deck = new ArrayList<>();
        loadDeck();
        shuffle();
    }

    public Card dealCard(){
        return deck.remove(0);
    }


    //adds all 52 cards to the deck
    public void loadDeck(){
        for(Rank r: Rank.values()){
            for(Suit s: Suit.values()){
                deck.add(new Card(s,r));
            }
        }
    }

    //Had problems with the shuffle method so i had to debug with ChatGPT
    //Still the same shuffle mode but different order
    //swaps card at deck.size() and the random number between 0 and i
    public void shuffle() {
        for (int i = deck.size() - 1; i > 0; i--) {
            int r = (int)(Math.random() * (i + 1));
            Card temp = deck.get(i);
            deck.set(i, deck.get(r));
            deck.set(r, temp);
        }
    }
}