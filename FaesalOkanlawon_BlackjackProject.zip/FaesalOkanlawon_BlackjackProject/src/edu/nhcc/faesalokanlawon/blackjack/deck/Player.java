package edu.nhcc.faesalokanlawon.blackjack.deck;

import java.util.ArrayList;

public class Player {
    private ArrayList<Card> hand;
    private String name;
    private double wallet;

    public Player(String n, double m){
        name = n;
        wallet = m;
        hand = new ArrayList<>();
    }

    public void takeCard(Card c){
        hand.add(c);
    }
    public ArrayList<Card> getHand() {
        return hand;
    }

    public String getName() {
        return name;
    }

    public double getWallet() {
        return wallet;
    }

    public void setWallet(double wallet) {
        this.wallet = wallet;
    }
}