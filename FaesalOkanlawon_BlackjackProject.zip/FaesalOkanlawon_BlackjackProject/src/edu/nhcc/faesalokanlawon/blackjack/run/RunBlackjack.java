package edu.nhcc.faesalokanlawon.blackjack.run;

import edu.nhcc.faesalokanlawon.blackjack.deck.*;
import edu.nhcc.faesalokanlawon.blackjack.game.*;
import edu.nhcc.faesalokanlawon.blackjack.game.BlackjackGUI;

import java.util.ArrayList;

public class RunBlackjack {
    public static void main(String[] args) {
        // Create players
        Player player1 = new Player("Gabriel", 100);
        Player player2 = new Player("Faith", 100);
        ArrayList<Player> players = new ArrayList<>();
        players.add(player1);
        players.add(player2);

        // Create a deck of cards
        Deck deck = new Deck();

        // Create the GUI
        BlackjackGUI gui = new BlackjackGUI();

        // Create the game
        Game game = new Game(players, deck, gui);

        // Run the game
        game.start();


    }
}