package edu.nhcc.faesalokanlawon.blackjack.game;

import edu.nhcc.faesalokanlawon.blackjack.deck.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Game {
    private final ArrayList<Player> players;
    private final Player dealer;
    private Deck deck;
    private final Scanner scanner;
    private final BlackjackGUI gui;

    public Game(ArrayList<Player> players, Deck deck, BlackjackGUI gui) {
        this.players = players;
        dealer = new Player("Dealer", 0);
        this.deck = deck;
        this.gui = gui;
        scanner = new Scanner(System.in);
    }

    public ArrayList<Card> getDealerHand() {
        return dealer.getHand();
    }


    // Displays a message and run the initial dealing of
    // card which passes two cards to all players and dealer
    public void start() {
        System.out.println("Welcome to Blackjack!");
        dealInitialCards();
        playRound();
    }

    public void GUIstart() {
        dealInitialCards();
    }

    // Take two card each for all players and dealer
    private void dealInitialCards() {
        for (int i = 0; i < 2; i++) {
            for (Player player : players) {
                player.takeCard(deck.dealCard());
            }
            dealer.takeCard(deck.dealCard());
        }
    }

    public void playRound() {
        //print all the players card but only the first card drawn by the dealer
        printPlayerHands();
        printDealerHand(false);
        for (Player player : players) {
            playerTurn(player);
        }
        // Show all of the dealer's cards after all the player have had their turn
        printDealerHand(true);
        // once all the player bust or do not hit it's dealer's turn
        dealerTurn();
        determineWinners();
    }

    //Could not figure this part out so
    //i has to check stackoverflow for the code to determine the winners

    private void determineWinners() {
        int dealerHandValue = calculateHandValue(dealer);
        for (Player player : players) {
            int playerHandValue = calculateHandValue(player);
            if (playerHandValue > 21) {
                System.out.println(player.getName() + " busts!");
            } else if (dealerHandValue > 21 || playerHandValue > dealerHandValue) {
                System.out.println(player.getName() + " wins!");
                player.setWallet(player.getWallet() + 2); // Player would wins double of their bets
                System.out.println(player.getName() + "'s money left:" + player.getWallet());
            } else if (playerHandValue == dealerHandValue) {
                System.out.println(player.getName() + " ties with the dealer. Bet returned.");
                player.setWallet(player.getWallet() + 1); // Player gets their bet back
                System.out.println(player.getName() + "'s money left:" + player.getWallet());
            } else {
                System.out.println(player.getName() + " loses.");
            }
        }
    }

    // print the cards drawn by all players and the total value
    private void printPlayerHands() {
        for (Player player : players) {
            System.out.println(player.getName() + "'s Hand:");
            for (Card card : player.getHand()) {
                System.out.println(card);
            }
            System.out.println("Total Value: " + calculateHandValue(player));
            System.out.println();
        }
    }

    //calculate the value of all the cards getting drawn by incrementing value by rankvalue
    //Checks to change ace's value if it's going to bust
    private int calculateHandValue(Player player) {
        int value = 0;
        boolean hasAce = false;
        for (Card card : player.getHand()) {
            value += card.getRankValue();
            // Check if it's an Ace
            if (card.getRankValue() == 1) {
                hasAce = true;
            }
        }
        //Ace is 11 as long as it won't bust the hand
        if (hasAce && value + 10 <= 21) {
            value += 10;
        }
        return value;
    }

    //print the dealer's cards and the total value
    //if all the players are done showAllCards would be true and all the card would be printed
    //else print only the first card
    private void printDealerHand(boolean showAllCards) {
        System.out.println("Dealer's Hand:");
        ArrayList<Card> dealerHand = dealer.getHand();
        if (showAllCards) {
            for (Card card : dealerHand) {
                System.out.println(card);
            }
            System.out.println("Total Value: " + calculateHandValue(dealer));
        } else {
            System.out.println(dealerHand.get(0)); // Only show the first card
        }
        System.out.println();
    }

    // display the message to hit or stand and take letter h or s ignoring the case of the letter
    // if the player hits deal the card to remove the top card and shrink the decksize
    // print the card returned by the dealcard class
    // create an int to store the hand value from the new calculated hand value and print it
    // if the handvalue is greater than 21 the player busts
    private void playerTurn(Player player) {
        System.out.println(player.getName() + "'s Turn:");
        while (true) {
            System.out.println("Do you want to Hit (H) or Stand (S)?");
            String choice = scanner.nextLine();
            if (choice.equalsIgnoreCase("H")) {
                Card newCard = deck.dealCard();
                player.takeCard(newCard);
                System.out.println(player.getName() + " draws: " + newCard);
                int handValue = calculateHandValue(player);
                System.out.println("Total Value: " + handValue);
                if (handValue > 21) {
                    System.out.println("Busted! " + player.getName() + " loses.");
                    break;
                }
            }
            else if (choice.equalsIgnoreCase("S")) {
                break;
            }
            else {
                System.out.println("Invalid choice. Please enter 'H' to Hit or 'S' to Stand.");
            }
        }
    }

    //Dealer has to take a card if his card does not total 17 or higher
    //Dealer busts if the value is greater than 21
    //print the dealer's total value

    private void dealerTurn() {
        System.out.println("Dealer's Turn:");
        while (calculateHandValue(dealer) < 17) {
            Card newCard = deck.dealCard();
            dealer.takeCard(newCard);
            System.out.println("Dealer draws: " + newCard);
        }
        int dealerHandValue = calculateHandValue(dealer);
        System.out.println("Dealer's Total Value: " + dealerHandValue);
        if (dealerHandValue > 21) {
            System.out.println("Dealer Busts! Players win.");
        }
    }
}