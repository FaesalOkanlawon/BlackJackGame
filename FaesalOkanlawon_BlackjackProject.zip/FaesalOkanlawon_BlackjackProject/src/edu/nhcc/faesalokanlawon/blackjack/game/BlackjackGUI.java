package edu.nhcc.faesalokanlawon.blackjack.game;

import edu.nhcc.faesalokanlawon.blackjack.deck.Card;
import edu.nhcc.faesalokanlawon.blackjack.deck.Deck;
import edu.nhcc.faesalokanlawon.blackjack.deck.Player;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class BlackjackGUI extends JFrame {
    private JButton hitButton;
    private JButton standButton;
    int boardWidth = 600;
    int boardHeight = boardWidth;
    int cardWidth = 110;
    int cardHeight = 154;
    private Deck deck = new Deck();
    private Player player1 = new Player("Gabriel", 100);
    ArrayList<Card> playerHand = player1.getHand();


    // Create the game
    public BlackjackGUI() {
        setTitle("Blackjack");
        setSize(boardWidth, boardHeight);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        initComponents();
    }


    private void initComponents() {
        JPanel gamePanel = new JPanel(new BorderLayout()){
            @Override
            public void paintComponent(Graphics g){
                super.paintComponent(g);

                //draw hidden card
                Image hiddenCardImg = new ImageIcon(getClass().getResource("./cards/BACK.png")).getImage();
                g.drawImage(hiddenCardImg, 20,20, cardWidth, cardHeight, null);


                ArrayList<Player> players = new ArrayList<>();

                players.add(player1);

                // Create the GUI
                BlackjackGUI gui = new BlackjackGUI();

                // Create the game
                Game game = new Game(players, deck, gui);

                game.GUIstart();

                ArrayList<Card> dealerHand = game.getDealerHand();
                for (int i = 0; i < dealerHand.size()-1; i++) {
                    Card card = dealerHand.get(i);
                    Image cardImg = new ImageIcon(getClass().getResource(card.getImagePath())).getImage();
                    g.drawImage(cardImg, cardWidth + 25 + (cardWidth + 5) * i, 20, cardWidth, cardHeight, null);
                }

                for (int i = 0; i < playerHand.size(); i++) {
                    Card card = playerHand.get(i);
                    Image cardImg = new ImageIcon(getClass().getResource(card.getImagePath())).getImage();
                    g.drawImage(cardImg, 20 + (cardWidth + 5) * i, 320, cardWidth, cardHeight, null);
                }
            }
        };
        // Add main panel to frame
        add(gamePanel);
        gamePanel.setBackground(new Color(53, 101, 77));

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        hitButton = new JButton("Hit");
        standButton = new JButton("Stand");
        buttonPanel.add(hitButton);
        buttonPanel.add(standButton);
        gamePanel.add(buttonPanel, BorderLayout.SOUTH);


        // Add action listeners to buttons
        hitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                    Card card = deck.dealCard();
                    playerHand.add(card);
                    repaint();
            }
        });


        standButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                BlackjackGUI gui = new BlackjackGUI();
                gui.setVisible(true);
            }
        });
    }
}

